# CALBOK brand assets

Original owner-supplied artwork: calbok-logo.png (400 × 400) and calbok-share.png (1500 × 500). Neither PNG has been recolored or redrawn. SVG mark and social files embed those exact PNGs; they are wrappers, not traced vector originals. The wordmark pairs the original icon with CALBOK text.

Forest #142C25; Paper #F4F2E9; Sage #D5E6BF; Orange #EF7145. Record #174C3C and Receipt #FFFEF8 are supporting colors. Orange buttons use forest text for contrast; links on paper use the darker orange #9E3E21.
